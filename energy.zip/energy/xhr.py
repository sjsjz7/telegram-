import logging
import json
import time
import requests
import re
import hashlib
import http.client
import base58
import subprocess
import mysql.connector
import random
import os
import hmac
import traceback
import threading
import urllib3.exceptions
import asyncio
from decimal import Decimal
from telegram import ReplyKeyboardRemove
from threading import Thread
from tronapi import Tron
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime, timedelta
from telegram import InlineKeyboardButton
from telegram import InlineKeyboardMarkup
from multiprocessing import Pool
from telegram.ext import CallbackQueryHandler
from concurrent.futures import ThreadPoolExecutor
from tronapi.exceptions import TransportError
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from pytz import utc
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Updater, CommandHandler, CallbackContext, CallbackQueryHandler
from datetime import datetime
from telegram.error import TelegramError
from telegram import ForceReply
from mysql.connector import errors
from telegram.error import NetworkError
from requests.exceptions import ReadTimeout, ConnectionError
import pytz

TRON_API_KEY = "5f97c7b8-05a1-4a27-bf79-e83d80510b58"
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
os.chdir(os.path.dirname(os.path.abspath(__file__)))
utotrc_huilv = 11.5
tron = Tron()

filename = '监听.txt'
contract_address = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t'
last_message_id = None
user_payment_amount = {}
INPUT_ADDRESS = 1
delete_ADDRESS = 4


# recharged_addresses = set()

class DatabaseConnection:
    def __init__(self, config):
        self.config = config
        self.conn = self.connect()

    def connect(self):
        return mysql.connector.connect(**self.config)

    def reconnect(self):
        self.conn.close()
        self.conn = self.connect()

    def cursor(self):
        while True:
            try:
                cursor = self.conn.cursor()
                break
            except (errors.InterfaceError, errors.OperationalError):
                self.reconnect()

        return cursor

    def close(self):
        self.conn.close()


def create_database(connection):
    cursor = connection.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT,
        chat_id BIGINT NOT NULL,
        amount INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    )
    """)
    cursor = connection.cursor()
    cursor.execute('SELECT 1')
    result = cursor.fetchone()
    if result and result[0] == 1:
        print('Connected to the database')
    else:
        print('Failed to connect to the database')
    cursor.close()


def get_user_data(chat_id):
    global connection
    cursor = connection.cursor()
    # 调整SQL查询为SELECT id, amount, created_at
    query = '''
    SELECT id, amount, created_at FROM transactions WHERE chat_id = %s FOR UPDATE
    '''
    cursor.execute(query, (chat_id,))
    result = cursor.fetchone()
    cursor.close()
    if result:
        amount = result[1]  # 修改索引以获取正确的余额字段
        created_at = result[2]  # 更新索引以获取正确的创建时间字段
        return {"amount": amount, "created_at": created_at}
    else:
        return None


def start(update: Update, context: CallbackContext):
    file_path = f"start.txt"
    data = ""
    if not os.path.exists(file_path):
        with open(file_path, "w", encoding="utf-8") as f:
            pass
    with open(file_path, "r", encoding="utf-8") as f:
        data = f.read()
    if update.message.chat.type == 'private':
        keyboard = [
            ["🛎预存扣费", "💹USDT转TRX"],
            ["查交易", "🔋TRX转能量"],
            ["已监听地址", "开始/结束监听"],
            ["💰我要充值", "👤个人中心"],
        ]

        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)
        update.message.reply_text(data, reply_markup=reply_markup, parse_mode='Markdown', disable_web_page_preview=True)
    else:
        update.message.reply_text(data, reply_markup=ReplyKeyboardRemove(), parse_mode='Markdown',
                                  disable_web_page_preview=True)


def read_config(file_path: str) -> dict:
    config = dict()
    with open(file_path, 'r') as file:
        for line in file.readlines():
            key, value = line.strip().split('=')
            config[key] = value
    return config


def get_u_trs_huilv():
    filenames = 'huilv.txt'
    if not os.path.exists(filenames):
        open(filename, "w").close()
    with open(filenames, 'r') as file:
        for line in file:
            utotrc_huilv = float(line.strip())
    return utotrc_huilv


def get_account_info(address):
    url = f"https://apilist.tronscan.org/api/account?address={address}"
    try:
        response = requests.get(url)
        account_info = response.json()
    except requests.exceptions.JSONDecodeError:
        print("Error: Received an invalid response from the server.")
        return None, None, None, None
    balance = int(account_info["balance"]) / 1000000  # TRX 余额（单位：TRX）
    energy_used = account_info["bandwidth"]["energyUsed"]
    energy_limit = account_info["bandwidth"]["energyLimit"]
    energy_remaining = energy_limit - energy_used
    bandwidth_used = account_info["bandwidth"]["freeNetUsed"]
    bandwidth_limit = account_info["bandwidth"]["freeNetLimit"]
    bandwidth_remaining = bandwidth_limit - bandwidth_used

    trc20_balances = account_info.get("trc20token_balances", [])
    usdt_balance = None
    for balance_info in trc20_balances:
        if balance_info["tokenAbbr"] == "USDT":
            usdt_balance = int(balance_info["balance"]) / (10 ** balance_info["tokenDecimal"])
            break
    if usdt_balance == None:
        usdt_balance = 0.0

    return energy_remaining, bandwidth_remaining, balance, usdt_balance


def check_trx_balance(tron_address):
    try:
        hex_address = tron.address.to_hex(tron_address)
        url = 'https://api.trongrid.io/wallet/getaccount'
        headers = {
            'Content-Type': 'application/json',
            'TRON-PRO-API-KEY': TRON_API_KEY
        }
        data = {'address': hex_address}
        response = requests.post(url, headers=headers, data=json.dumps(data))
        result = response.json()
        if 'balance' in result and result['balance'] is not None:
            balance = int(result['balance']) / 1000000
            return balance;
        else:
            return 0.000
    except ValueError as e:
        return 0.000


def check_usdt_balance(tron_address):
    result = subprocess.check_output(['node', 'get_balance.js', tron_address])
    result_str = result.decode('utf-8').strip()
    balance = float(result_str)
    return balance


# def get_trxmultiSign(privateKey,mainAddress,toAddress,amount):
#     result = subprocess.check_output(['node', 'trxmultiSign.js', privateKey, mainAddress, toAddress, str(amount)])
#     trn= json.loads(result.decode('utf-8'))
#     return trn
def compare_amounts(transaction_data, address_amounts):
    successMatches = {}
    for chat_id, amount in transaction_data.items():
        if chat_id in address_amounts and address_amounts[chat_id] == amount:
            successMatches[chat_id] = amount
    return successMatches


def upload_to_server(data):
    global connection
    cursor = connection.cursor()

    # 查询数据库中是否已存在 chat_id 对应的记录
    find_chat_id_query = '''
    SELECT * FROM transactions WHERE chat_id = %s
    '''
    cursor.execute(find_chat_id_query, (data['chat_id'],))

    # 查询结果
    result = cursor.fetchone()

    # 如果结果存在，则更新金额，否则插入新记录
    if result:
        update_amount_query = '''
        UPDATE transactions SET amount = amount + %s WHERE chat_id = %s
        '''
        cursor.execute(update_amount_query, (data['amount'], data['chat_id']))
    else:
        insert_data_query = '''
        INSERT INTO transactions (chat_id, amount)
        VALUES (%s, %s)
        '''
        cursor.execute(insert_data_query, (data['chat_id'], data['amount']))

    # 提交更改
    connection.conn.commit()

    # 查询更新后的余额
    cursor.execute(find_chat_id_query, (data['chat_id'],))
    new_result = cursor.fetchone()
    new_balance = new_result[2]  # 从新结果中获取更新后的金额

    # 关闭游标
    cursor.close()

    # 返回最新余额
    return new_balance


def process_block(block, formatted_date_time, chat_id_jiantingaddress, dizhi_jiantingaddress, transaction_data):
    try:
        with ThreadPoolExecutor() as executor:
            for transaction in block['transactions']:
                executor.submit(process_transaction, transaction, formatted_date_time, chat_id_jiantingaddress,
                                dizhi_jiantingaddress, transaction_data)
    except Exception as e:
        print(f"process_transaction出现问题: {e}")


def process_transaction(transaction, formatted_date_time, chat_id_jiantingaddress, dizhi_jiantingaddress,
                        transaction_data):
    global bot
    linshi = transaction['ret'][0]
    transaction_id = transaction['txID']
    keyboard = [
        [
            InlineKeyboardButton("USDT转TRX", callback_data="💹USDT转TRX"),
            InlineKeyboardButton("TRX转能量", callback_data="🔋TRX转能量"),
        ]
    ]
    chat_id = YOUR_CHANNEL_ID
    reply_markup = InlineKeyboardMarkup(keyboard)
    if 'ret' in transaction and 'contractRet' in linshi and linshi['contractRet'] == 'SUCCESS':
        parameter = transaction['raw_data']['contract'][0]
        linshizhi = parameter['parameter']['value']
        # trc20交易
        if 'TriggerSmartContract' == parameter['type'] and '41a614f803b6fd780986a42c78ec9c7f77e6ded13c' == linshizhi[
            'contract_address']:
            to_address = tron.address.from_hex('41' + linshizhi['data'][32:72]).decode()
            if linshizhi['data'][:8] == 'a9059cbb':
                if to_address == control_address:  # 23b872dd和a9059cbb
                    from_address = tron.address.from_hex(linshizhi['owner_address']).decode()
                    us_amount = int(linshizhi['data'][72:136], 16)
                    if us_amount >= 1000000:
                        sender_trx = gethuilv() * float(us_amount)
                        if sender_trx < check_trx_balance(control_address) * 1000000:  # 检查余额是否够,ceshi
                            # trn = get_trxmultiSign(privateKey, control_address, from_address, sender_trx)  #多签调用
                            private_key = privateKey
                            tron.private_key = private_key
                            tron.default_address = tron.address.from_private_key(private_key).base58
                            try:
                                trx_to_send = float(sender_trx) / 1000000
                                transaction = tron.trx.send_transaction(from_address, trx_to_send)
                                if (transaction['result']):
                                    amount = \
                                        transaction['transaction']['raw_data']['contract'][0]['parameter']['value'][
                                            'amount']
                                    txid = transaction['txid']
                                    chat_id = YOUR_CHANNEL_ID
                                    xiangqing = f"https://tronscan.org/?utm_source=tronlink #/transaction/{txid}?lang=zh"
                                    for chat_id in all_chats:
                                        bot.send_message(chat_id=chat_id,
                                                         text=f"✅兑换成功,收到{float(us_amount / 1000000)}USDT,向账号{from_address}转账{float(amount) / 1000000}TRX\n[点击查看交易详情]({xiangqing})",
                                                         parse_mode='Markdown', disable_web_page_preview=True,
                                                         reply_markup=reply_markup)

                            except Exception as e:
                                print(f"错误，Error sending message to chat_id {chat_id}: {e}")
                        else:
                            trx_to_send = round(float(sender_trx) / 1000000, 2)
                            try:
                                bot.send_message(chat_id=admin_id,
                                                 text=f'余额不足，交易失败  \n哈希：`{transaction_id}`  \n地址：`{from_address}`  \nU金额：{float(us_amount) / 1000000}\n应转：{trx_to_send}TRX',
                                                 parse_mode='Markdown')
                            except Exception as e:
                                print(f"错误，Error sending message to chat_id {chat_id}: {e}")
                else:
                    linshizhi_data = linshizhi['data']
                    from_address = tron.address.from_hex(linshizhi['owner_address']).decode()
                    if from_address in dizhi_jiantingaddress:  # 23b872dd和a9059cbb
                        us_amount = int(linshizhi_data[72:136], 16)
                        if us_amount >= 1000000:
                            chat_ids = [chat_id for chat_id, jiantingaddress in chat_id_jiantingaddress if
                                        jiantingaddress == from_address]
                            _, _, balance, usdt_balance = get_account_info(from_address)
                            for chat_id in chat_ids:
                                try:

                                    jiantingtext = f'❎*支出提醒 -{float(us_amount) / 1000000}USDT*\n付款地址：`{from_address}` \n收款地址：`{to_address}`\n交易时间：{formatted_date_time}\n交易金额：{float(us_amount) / 1000000}USDT' \
                                                   f'\n账户余额：{round(balance, 2)}TRX，{round(usdt_balance, 2)}USDT'
                                    bot.send_message(chat_id, jiantingtext, parse_mode='Markdown',
                                                     disable_web_page_preview=True, reply_markup=reply_markup)
                                except Exception as e:
                                    print(f"Error sending message to chat_id {chat_id}: {e}")
                                    continue
                    if to_address in dizhi_jiantingaddress:  # 收入
                        us_amount = int(linshizhi_data[72:136], 16)
                        if us_amount >= 1000000:
                            chat_ids = [chat_id for chat_id, jiantingaddress in chat_id_jiantingaddress if
                                        jiantingaddress == to_address]
                            _, _, balance, usdt_balance = get_account_info(to_address)
                            for chat_id in chat_ids:
                                try:
                                    jiantingtext = f'✅*收入到账 +{float(us_amount) / 1000000}USDT*\n付款地址：`{from_address}` \n收款地址：`{to_address}`\n交易时间：{formatted_date_time}\n交易金额：{float(us_amount) / 1000000}USDT' \
                                                   f'\n账户余额：{round(balance, 2)}TRX，{round(usdt_balance, 2)}USDT'
                                    bot.send_message(chat_id, jiantingtext, parse_mode='Markdown',
                                                     disable_web_page_preview=True, reply_markup=reply_markup)
                                except Exception as e:
                                    print(f"Error sending message to chat_id {chat_id}: {e}")
                                    continue
        elif 'TransferContract' == parameter['type']:
            linshizhi = parameter['parameter']['value']
            to_address = tron.address.from_hex(linshizhi['to_address']).decode()
            from_address = tron.address.from_hex(linshizhi['owner_address']).decode()
            if to_address == control_address:
                us_amount = int(linshizhi['amount'])
                # 直接在主代码中比较金额并提取匹配的chat_id
                matched_chat_id = None
                if len(transaction_data) > 0:
                    for chat_id, amount in transaction_data.items():
                        amount = Decimal(amount).quantize(Decimal('1.000000'))
                        if amount * 1000000 == us_amount:
                            data_to_upload = {"chat_id": chat_id, "amount": us_amount}
                            balance = upload_to_server(data_to_upload)
                            try:
                                bot.send_message(chat_id=chat_id,
                                                 text=f'充值成功,您的余额已更新\n目前余额：{balance / 1000000}TRX',
                                                 reply_markup=reply_markup)
                                bot.send_message(chat_id=admin_id,
                                                 text=f'用户{chat_id}，充值{us_amount / 1000000}TRX,\n目前余额：{balance / 1000000}TRX')
                            except Exception as e:
                                print(f"Error sending message to chat_id {chat_id}: {e}")
                                return
                energy_params = {
                    3000000: ("32000", "1小时1次", '1h'),
                    3000000 * 2: ("64000", "1小时2次", '1h'),
                    3000000 * 5: ("160000", "1小时5次", '1h'),
                    3000000 * 10: ("320000", "1小时10次", '1h'),
                    5000000 * 5: ("160000", "1天5次", '1D'),
                    5000000 * 10: ("320000", "1天10次", '1D'),
                    5000000 * 30: ("960000", "1天30次", '1D'),
                    5000000 * 50: ("1600000", "1天50次", '1D'),
                    30000000 * 10: ("320000", "3天内每天10次", '3D'),
                    30000000 * 20: ("640000", "3天内每天20次", '3D'),
                    30000000 * 30: ("960000", "3天内每天30次", '3D'),
                    30000000 * 50: ("1600000", "3天内每天50次", '3D'),
                }

                # 查找指定的 us_amount
                if us_amount in energy_params:
                    energy, desc, days = energy_params[us_amount]
                    result = nl_itrx(int(energy), days, from_address, 0)
                    # 检查errno是否为0
                    if result.get('errno') == 0:
                        for chat_id in all_chats:
                            try:
                                # 发送兑换成功的通知
                                bot.send_message(
                                    chat_id=chat_id,
                                    text=f"✅兑换成功,地址{from_address}，能量{energy}已兑换成功，{desc}转账有效，请及时使用",
                                    reply_markup=reply_markup,
                                )
                            except Exception as e:
                                print(f"Error sending message to group {group_id}: {e}")
                    else:
                        try:
                            bot.send_message(
                                chat_id=admin_id,
                                text=f"兑换失败,地址{from_address}，详情{result_dict}",
                                reply_markup=reply_markup,
                            )
                        except Exception as e:
                            print(f"Error sending message to chat_id {admin_id}: {e}")

            if to_address in dizhi_jiantingaddress:  # 收入
                us_amount = int(linshizhi['amount'])
                if us_amount >= 1000000:
                    chat_ids = [chat_id for chat_id, jiantingaddress in chat_id_jiantingaddress if
                                jiantingaddress == to_address]
                    _, _, balance, usdt_balance = get_account_info(to_address)
                    for chat_id in chat_ids:
                        try:
                            jiantingtext = f'✅*收入到账   +{float(us_amount) / 1000000}TRX*\n付款地址：`{from_address}` \n收款地址：`{to_address}`\n交易时间：{formatted_date_time}\n交易金额：{float(us_amount) / 1000000}TRX' \
                                           f'\n账户余额：{round(balance, 2)}TRX，{round(usdt_balance, 2)}USDT'
                            bot.send_message(chat_id, jiantingtext, parse_mode='Markdown',
                                             disable_web_page_preview=True, reply_markup=reply_markup)
                        except Exception as e:
                            print(f"Error sending message to chat_id {chat_id}: {e}")
                            continue
            if from_address in dizhi_jiantingaddress:  # 支出
                us_amount = int(linshizhi['amount'])
                if us_amount >= 1000000:
                    chat_ids = [chat_id for chat_id, jiantingaddress in chat_id_jiantingaddress if
                                jiantingaddress == from_address]
                    _, _, balance, usdt_balance = get_account_info(from_address)
                    for chat_id in chat_ids:
                        try:
                            jiantingtext = f'❎*支出提醒  -{float(us_amount) / 1000000}TRX*\n付款地址：`{from_address}` \n收款地址：`{to_address}`\n交易时间：{formatted_date_time}\n交易金额：{float(us_amount) / 1000000}TRX' \
                                           f'\n账户余额：{round(balance, 2)}TRX，{round(usdt_balance, 2)}USDT'
                            bot.send_message(chat_id, jiantingtext, parse_mode='Markdown',
                                             disable_web_page_preview=True, reply_markup=reply_markup)
                        except Exception as e:
                            print(f"Error sending message to chat_id {chat_id}: {e}")
                            continue


def saokuai():
    full_node = 'https://api.trongrid.io'
    solidity_node = 'https://api.trongrid.io'
    event_server = 'https://api.trongrid.io'

    tron = Tron(full_node=full_node,
                solidity_node=solidity_node,
                event_server=event_server,
                headers={
                    'TRON-PRO-API-KEY': TRON_API_KEY
                })

    current_block_number = tron.trx.get_current_block()['block_header']['raw_data']['number']
    # 在这里运行您的代码
    last_processed_block_number = None
    while True:
        start_time = time.time()  # 获取当前时间
        # Get the latest block number
        all_time = 3.0
        # 跳过已经处理过的块
        if last_processed_block_number == current_block_number:
            print(f"Skipping block {current_block_number} because it's already processed.")
            current_block_number += 1
            continue
        try:
            try:
                if current_block_number is None:
                    print(f"current_block_number occurred")
                url = "https://api.trongrid.io/wallet/getblockbynum"
                params = {"num": current_block_number}
                headers = {"Content-Type": "application/json", "TRON-PRO-API-KEY": TRON_API_KEY}
                response = requests.post(url, json=params, headers=headers, timeout=10)
                if response.status_code != 200:
                    print(response.text)
                    time.sleep(2)
                    continue
                block = response.json()
                if not block:
                    print(f"Block data is empty for block number: {current_block_number}")
                    time.sleep(2)
                    continue
                if block.get("transactions") is None:
                    time.sleep(2)
                    current_block_number += 1
                    continue
            except Exception as e:
                # 通用异常处理
                print(f"An unexpected error occurred: {e}")
                time.sleep(2)
                continue
            transaction_data = []
            if os.stat("transaction_data.txt").st_size != 0:
                transaction_data = read_data_from_file("transaction_data.txt")
            if 'transactions' in block and block['transactions']:
                qukuaitimestamp = block['block_header']['raw_data']['timestamp']
                date_time = datetime.fromtimestamp(qukuaitimestamp / 1000)
                formatted_date_time = date_time.strftime("%Y-%m-%d %H:%M:%S")
                if abs(int(time.time()) - qukuaitimestamp / 1000) > 5:
                    all_time = 1.8
                filename = '监听.txt'
                if not os.path.exists(filename):
                    return
                chat_id_jiantingaddress = []
                dizhi_jiantingaddress = set()
                with open(filename, "r") as file:
                    for line in file:
                        timestamp, chat_id_str, address_str = line.strip().split(" - ")
                        chat_id = chat_id_str.split(": ")[1]
                        jiantingaddress = address_str.split(": ")[1]
                        chat_id_jiantingaddress.append((chat_id, jiantingaddress))
                        dizhi_jiantingaddress.add(jiantingaddress)
                    # 在你的主循环中调用 process_block() 函数来处理区块
                process_block(block, formatted_date_time, chat_id_jiantingaddress, dizhi_jiantingaddress,
                              transaction_data)
                last_processed_block_number = current_block_number  # 更新已处理块编号
                current_block_number += 1
            else:
                print(f"block--{block}")
        except Exception as e:  # 添加一个通用异常处理程序
            print(f"程序异常，请检查服务器{e}")

        end_time = time.time()  # 获取当前时间
        elapsed_time = end_time - start_time  # 计算运行时间

        # Wait for the next poll
        interval = max(all_time - elapsed_time, 0)  # 确保interval不小于0
        time.sleep(interval)


def read_data_from_file(filename):
    data = {}
    lines_to_keep = []

    with open(filename, "r") as file:
        for line in file:
            record = line.strip().split(",")
            amount = float(record[0])
            expiration_time = record[1]
            chat_id = int(record[2])

            # 解析过期时间
            expiration_datetime = datetime.strptime(expiration_time, '%Y-%m-%d %H:%M:%S')

            # 获取当前时间
            now = datetime.now()

            # 如果当前时间小于过期时间，表示记录仍有效，则添加到数据字典中
            if now < expiration_datetime:
                data[chat_id] = amount
                lines_to_keep.append(line)
            # 否则，不要保留这行

    # 使用"lines_to_keep"中保留的行覆盖原始文件
    with open(filename, "w") as file:
        file.writelines(lines_to_keep)

    return data


def get_amount_from_file(filename, from_address):
    if not os.path.exists(filename):
        open(filename, "w").close()
    with open(filename, 'r') as f:
        for line in f:
            address, value = line.strip().split()
            if address == from_address:
                return float(value)
            else:
                return None
    return None


def get_amount_from_file(filename, from_address):
    if not os.path.exists(filename):
        open(filename, "w").close()
    with open(filename, 'r') as f:
        for line in f:
            address, value, _ = line.strip().split()
            if address == from_address:
                return float(value)
    return None


def handle_message(update: Update, context: CallbackContext):
    if update.message is not None and update.message.chat.type == 'private':
        chat_id = update.effective_chat.id
        message_text = update.message.text
        # 保存每天聊天记录
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        liaotianriqi = datetime.now().strftime("%Y-%m-%d")
        if not os.path.exists(f"{liaotianriqi}.txt"):
            open(f"{liaotianriqi}.txt", "w", encoding='utf-8').close()
        with open(f"{liaotianriqi}.txt", "a", encoding='utf-8') as file:
            file.write(f"{timestamp} - chat_id: {chat_id} - Message: {message_text}\n")
        if message_text == '已监听地址':
            filename = '监听.txt'
            if not os.path.exists(filename):
                update.message.reply_text("暂无地址")
                return
            chat_id = update.effective_chat.id
            text = ""
            with open(filename, 'r') as f:
                for line in f:
                    if str(chat_id) in line:
                        addresss = line.split('地址: ')[-1].strip()
                        text += f"`{addresss}`\n"
            if text != "":
                update.message.reply_text(text, parse_mode='Markdown', disable_web_page_preview=True)
            else:
                update.message.reply_text("此账户无监听地址")
        if message_text == '开始/结束监听':
            update.message.reply_text(
                "每次只支持输入一个地址,监听包含trc20和trx\n格式(结束同理)：开始监听 地址（中间有空格）\n开始监听 TEfbxrUwvwZY8dYJx8tt7RXXXXXXXX")
        if message_text == "关闭监听":
            filename = '监听.txt'
            try:
                os.remove(filename)
            except FileNotFoundError:
                update.message.reply_text("没有找到要删除的文件")
        elif message_text == '💹USDT转TRX':
            keyboard = [
                [
                    InlineKeyboardButton("加入群组", url=group_link),
                    InlineKeyboardButton("联系客服", url=CUSTOMER_SERVICE_ID)
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            now_huilv = gethuilv()
            balance = check_trx_balance(control_address) / now_huilv
            rounded_balance = round(balance, 2)
            text = f"*当前可兑：{rounded_balance} USDT*\n" \
                   f"*当前兑换比例1:{now_huilv}*\n" \
                   f"24小时进U自动兑，1U起兑\n" \
                   f"收款trc20地址为：\n\n" \
                   f"`{control_address}`\n" \
                   "(点击可复制)\n" + "‼️*注意:请勿使用交易所转账,丢失自负*"
            update.message.reply_text(text, parse_mode='Markdown', disable_web_page_preview=True,
                                      reply_markup=reply_markup)
        elif message_text == '🔋TRX转能量':
            address_text = f"{control_address}"
            filename = "能量按钮.txt"
            buttons_data = read_buttons_from_txt(filename)
            # 提取文件中的文本和链接
            button_text, button_url = create_button_data(buttons_data[0])
            button_list = [
                [
                    InlineKeyboardButton("👇有效期1小时👇", callback_data="tittle"),

                ],
                [
                    InlineKeyboardButton("1次", callback_data="hour_1"),
                    InlineKeyboardButton("2次", callback_data="hour_2"),
                    InlineKeyboardButton("5次", callback_data="hour_5"),
                    InlineKeyboardButton("10次", callback_data="hour_10"),
                ],
                [
                    InlineKeyboardButton("👇有效期1天👇", callback_data="tittle"),

                ],
                # 注意这里添加了逗号
                [
                    InlineKeyboardButton("5次", callback_data="day_5"),
                    InlineKeyboardButton("10次", callback_data="day_10"),
                    InlineKeyboardButton("30次", callback_data="day_30"),
                    InlineKeyboardButton("50次", callback_data="day_50"),

                ],
                [
                    InlineKeyboardButton("👇有效期3天（每天笔数）👇", callback_data="tittle"),

                ],
                [
                    InlineKeyboardButton("10次", callback_data="day3_10"),
                    InlineKeyboardButton("20次", callback_data="day3_20"),
                    InlineKeyboardButton("30次", callback_data="day3_30"),
                    InlineKeyboardButton("50次", callback_data="day3_50"),
                ],
                [
                    InlineKeyboardButton(button_text, url=button_url),
                    InlineKeyboardButton("💹USDT转TRX", callback_data="💹USDT转TRX"),
                ],
                [
                    InlineKeyboardButton("3.0t一笔不限时(0.21U)", url=bot_id)
                ]
            ]
            # 创建键盘布局
            reply_markup = InlineKeyboardMarkup(button_list)
            text = f'*提示：所示金额为对方有U的转账手续费，如对方无U请再次购买*\n' \
                   f"‼️24小时自动到账，兑能量暂时不支持其他金额！\n" \
                   f"收款trc20接收地址为：\n" \
                   f"`{address_text}`\n" \
                   "(点击可复制)\n" + "*注意:请勿使用交易所转账,丢失自负*"

            update.message.reply_text(text, parse_mode='Markdown', disable_web_page_preview=True,
                                      reply_markup=reply_markup)
        elif message_text == '实时汇率':
            update.message.reply_text(f"实时 USDT 转 TRX 汇率：\n*{gethuilv()}*", parse_mode='Markdown',
                                      disable_web_page_preview=True)
        elif message_text == '查交易':
            update.message.reply_text(
                "查交易：\n格式：查交易 地址（中间有空格）\n查交易 TEfbxrUwvwZY8dYJx8tt7RXLF3XXXXXXXX")
        if "开启地址 " in message_text:
            split_str = message_text.split(' ')
            js_address = split_str[1]
            if tron.isAddress(js_address):
                chat_id = update.message.chat_id
                found = False
                with open('自动充.txt', 'r+', encoding='utf-8') as f:
                    lines = f.readlines()
                    f.seek(0)
                    for line in lines:
                        if f"chat_id: {chat_id} - 地址: {js_address} - 状态: " in line:
                            line = line.replace('关闭', '开启')
                            found = True
                        f.write(line)
                    f.truncate()
                if found:
                    update.message.reply_text(f"成功开启地址 {js_address}", parse_mode='Markdown',
                                              disable_web_page_preview=True)
                else:
                    update.message.reply_text(f"找不到对应地址 {js_address}", parse_mode='Markdown',
                                              disable_web_page_preview=True)
            else:
                update.message.reply_text("无效地址", parse_mode='Markdown', disable_web_page_preview=True)
        if "停用地址 " in message_text:
            split_str = message_text.split(' ')
            js_address = split_str[1]
            if tron.isAddress(js_address):
                print(js_address)
                chat_id = update.message.chat_id
                found = False
                with open('自动充.txt', 'r+', encoding='utf-8') as f:
                    lines = f.readlines()
                    f.seek(0)
                    for line in lines:
                        if f"chat_id: {chat_id} - 地址: {js_address} - 状态: " in line:
                            line = line.replace('开启', '关闭')
                            print(line)
                            found = True
                        f.write(line)
                    f.truncate()
                if found:
                    update.message.reply_text(f"成功停用地址 {js_address}", parse_mode='Markdown',
                                              disable_web_page_preview=True)
                else:
                    update.message.reply_text(f"找不到对应地址 {js_address}", parse_mode='Markdown',
                                              disable_web_page_preview=True)
            else:
                update.message.reply_text("无效地址", parse_mode='Markdown', disable_web_page_preview=True)
        if message_text == '🛎预存扣费':
            chat_id = update.message.chat_id
            user_data = get_user_data(chat_id)
            if user_data:
                balance = user_data["amount"]
                filenames = '自动充.txt'
                if (balance / 1000000) > 10:
                    if not os.path.exists(filenames):
                        open(filenames, "w").close()
                        return
                    chat_id = update.effective_chat.id
                    text = ""
                    with open(filenames, 'r', encoding='utf-8') as f:
                        for line in f:
                            if str(chat_id) in line:
                                parts = line.strip().split(' - ')
                                time_str, chat_id_str, address_str, status_str = parts
                                chat_id = int(chat_id_str.split(': ')[1])
                                address = address_str.split(': ')[1]
                                status = status_str.split(': ')[1]
                                text += f"`{address}` - {status}\n"
                    if text != "":
                        button_list = [
                            [
                                InlineKeyboardButton("绑定地址", callback_data="bangding"),
                                InlineKeyboardButton("删除地址", callback_data="shanchu"),
                            ]
                        ]
                        # 创建键盘布局
                        reply_markup = InlineKeyboardMarkup(button_list)
                        update.message.reply_text(
                            f"能量低于64000时自动补充，更省心\n已开启自动充值能量地址：\n{text}\n\n开启/停用地址的格式\n`开启地址` Txxxxxxxxxx（有一个空格）\n`停用地址` Txxxxxxxxxx（有一个空格）"
                            f"", parse_mode='Markdown', disable_web_page_preview=True, reply_markup=reply_markup)
                    else:
                        button_list = [
                            [
                                InlineKeyboardButton("绑定地址", callback_data="bangding"),
                            ]
                        ]
                        # 创建键盘布局
                        reply_markup = InlineKeyboardMarkup(button_list)
                        update.message.reply_text(
                            "此模式建议一天转账超过2次的地址使用，否则会造成能量浪费！\n\n能量低于64000时自动补充，更省心\n32000单价3.5trx，64000单价6.5trx\n此账户无自动充值能量的地址，点击按钮添加。",
                            reply_markup=reply_markup)
                else:
                    button_list = [
                        [
                            InlineKeyboardButton("50", callback_data="50"),
                            InlineKeyboardButton("100", callback_data="100"),

                        ],
                        [
                            InlineKeyboardButton("200", callback_data="200"),
                            InlineKeyboardButton("500", callback_data="500"),
                        ]
                    ]
                    # 创建键盘布局
                    reply_markup = InlineKeyboardMarkup(button_list)
                    text = f"您的余额不足，需保证余额大于10trx,请先充值\n\n*请在下方选择你要充值的金额*👇👇"
                    update.message.reply_text(text, parse_mode='Markdown', disable_web_page_preview=True,
                                              reply_markup=reply_markup)
            else:
                button_list = [
                    [
                        InlineKeyboardButton("50", callback_data="50"),
                        InlineKeyboardButton("100", callback_data="100"),

                    ],
                    [
                        InlineKeyboardButton("200", callback_data="200"),
                        InlineKeyboardButton("500", callback_data="500"),
                    ]
                ]
                # 创建键盘布局
                reply_markup = InlineKeyboardMarkup(button_list)
                text = f"您的余额不足，需保证余额大于10trx,请先充值\n\n*请在下方选择你要充值的金额*👇👇"
                update.message.reply_text(text, parse_mode='Markdown', disable_web_page_preview=True,
                                          reply_markup=reply_markup)

        if message_text.startswith("能量"):
            address = message_text[2:]  # 从索引 2 开始截取字符串，以获取地址
            if tron.isAddress(address):
                # 从之前存储的收款金额字典中提取金额
                payment_amount = user_payment_amount.get(chat_id, None)
                if payment_amount is not None:
                    button_list = [
                        [
                            InlineKeyboardButton("确认支付", callback_data="confirm"),
                            InlineKeyboardButton("取消订单", callback_data="cancel"),
                        ]
                    ]
                    # 创建键盘布局
                    reply_markup = InlineKeyboardMarkup(button_list)
                    # 发送确认消息给用户
                    confirm_text = f"您的订单信息如下：\n平台ID:{chat_id}\n能量接收地址：`{address}`\n消费金额：*{payment_amount}TRX*\n请确认以上信息是否正确。"
                    context.bot.sendMessage(chat_id=chat_id, text=confirm_text, parse_mode='Markdown',
                                            reply_markup=reply_markup)
                else:
                    context.bot.sendMessage(chat_id=chat_id, text="请重新选择消费金额", parse_mode='Markdown')
            else:
                context.bot.sendMessage(chat_id=chat_id, text="格式错误，请重新输入", parse_mode='Markdown')
        elif "查交易 " in message_text:
            split_str = message_text.split(' ')
            if tron.isAddress(split_str[1]):
                context.bot.send_message(chat_id=update.effective_chat.id,
                                         text=f"您的交易记录：\n{gettransaction(split_str[1])}\n{get_trx_transaction(split_str[1])}\n--------------",
                                         parse_mode='Markdown', disable_web_page_preview=True)
            else:
                context.bot.send_message(chat_id=update.effective_chat.id, text="请输入正确的trx地址")
        elif "chatid发送 " in message_text:  # 格式：chatid发送 524545 你好吗
            try:
                split_str = message_text.split(' ')
                Chat_id = split_str[1];
                text = split_str[2];
                context.bot.send_message(chat_id=Chat_id, text=text)
            except Exception as e:
                context.bot.send_message(chat_id=update.effective_chat.id, text="出现错误请检查" + str(e))
        if tron.isAddress(message_text):
            if context.user_data.get("bangding") == INPUT_ADDRESS:
                context.user_data["bangding"] = None
                address_dict = {}

                # 检查地址是否存在
                def check_address(address, chat_id):
                    if address in address_dict:
                        return chat_id in address_dict[address]
                    return False

                def add_address(address, chat_id):
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    if not check_address(address, chat_id):
                        # 在字典中为该地址添加新元素，表示该聊天窗口已开启自动充值，并将信息写入文件。
                        if address not in address_dict.keys():
                            address_dict[address] = []
                        address_dict[address].append(chat_id)
                        with open("自动充.txt", "a", encoding='utf-8') as file:
                            file.write(f"{timestamp} - chat_id: {chat_id} - 地址: {address} - 状态: 开启\n")
                        context.bot.send_message(chat_id=chat_id,
                                                 text=f"已添加{address}\n\n此地址能量低于64000时，本机器人将自动为您充值\n每次扣费3.5TRX\n请关注余额变化")
                    else:
                        context.bot.send_message(chat_id=chat_id, text=f"地址已存在！")

                filename = "自动充.txt"
                if os.path.exists(filename):
                    with open(filename, "r") as file:
                        for line in file:
                            timestamp, chat_id_str, address_str, status_str = line.strip().split(' - ')
                            chat_id = int(chat_id_str.split(': ')[-1])
                            address = address_str.split(': ')[-1]
                            if address not in address_dict.keys():
                                address_dict[address] = []
                                address_dict[address].append(chat_id)
                print(address_dict)
                chat_id = update.message.chat_id
                if check_address(message_text, chat_id):
                    print(f"地址已存在")
                    context.bot.send_message(chat_id=chat_id, text=f"地址已存在")
                else:
                    print(f"地址不存在")
                    add_address(message_text, chat_id)
                return
            if context.user_data.get("shanchu") == delete_ADDRESS:
                context.user_data["shanchu"] = None
                delete_address(chat_id, message_text)
                context.bot.send_message(chat_id=chat_id, text=f"已删除地址\n{message_text}")
                return
            else:
                # 调用函数并获取剩余能量和带宽
                energy_remaining, bandwidth_remaining, balance, usdt_balance = get_account_info(message_text)
                text = f"您的账户:`{message_text}`\n能量：{energy_remaining}\n带宽：{bandwidth_remaining}\nTRX余额:{balance}\nUSDT余额:{usdt_balance}"
                context.bot.send_message(chat_id=chat_id, text=text, parse_mode='Markdown')
        elif "开始监听 " in message_text:
            filename = "监听.txt"
            address_dict = {}

            # 检查地址是否存在
            def check_address(address, chat_id):
                if address in address_dict and chat_id in address_dict[address]:
                    return True
                return False

            # 添加新地址
            def add_address(address, chat_id):
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                if not check_address(address, chat_id):
                    with open(filename, "a") as file:
                        file.write(f"{timestamp} - chat_id: {chat_id} - 地址: {address}\n")
                        if address not in address_dict:
                            address_dict[address] = []
                        address_dict[address].append(chat_id)
                context.bot.send_message(chat_id=chat_ids, text=f"已添加" + split_str[1])

            split_str = message_text.split(' ')
            chat_ids = update.effective_chat.id
            if split_str[1] == control_address or split_str[1] == "TSaRZDiBPD8Rd5vrvX8a4zgunHczM9mj8S":
                context.bot.send_message(chat_id=chat_ids, text=f"此地址暂不支持监听")
                return
            if tron.isAddress(split_str[1]):
                # 初始化字典
                if os.path.exists(filename):
                    with open(filename, "r") as file:
                        for line in file:
                            timestamp, chat_id_str, address_str = line.split(' - ')
                            chat_id = int(chat_id_str.split(': ')[-1])
                            address = address_str.split(': ')[-1].strip()
                            if address not in address_dict:
                                address_dict[address] = []
                            address_dict[address].append(chat_id)
                if check_address(split_str[1], chat_ids):
                    context.bot.send_message(chat_id=chat_ids, text=f"地址已存在")
                else:
                    add_address(split_str[1], chat_ids)

            else:
                context.bot.send_message(chat_id=chat_ids, text="请输入正确的trx地址")

        elif "结束监听 " in message_text:
            split_str = message_text.split(' ')
            if tron.isAddress(split_str[1]):
                jt_adress = split_str[1]
                chat_id = update.effective_chat.id
                filename = '监听.txt'
                with open(filename, "r") as file:
                    lines = file.readlines()
                    new_lines = []
                    for line in lines:
                        if jt_adress in line:
                            # 找到包含 split_str[1] 的行
                            parts = line.split(" - ")
                            if parts[1].split(": ")[1] == str(chat_id):
                                # 如果 chat_id 也相同，则删除这一行
                                context.bot.send_message(chat_id=update.effective_chat.id,
                                                         text=f"已删除" + split_str[1])
                                continue
                        new_lines.append(line)
                # 将更新后的内容写回文件
                with open(filename, "w") as file:
                    file.writelines(new_lines)
            else:
                context.bot.send_message(chat_id=update.effective_chat.id, text="请输入正确的trx地址")
        if message_text == '💰我要充值':
            button_list = [
                [
                    InlineKeyboardButton("50", callback_data="50"),
                    InlineKeyboardButton("100", callback_data="100"),
                    InlineKeyboardButton("200", callback_data="200"),
                    InlineKeyboardButton("500", callback_data="500"),
                ]
            ]
            # 创建键盘布局
            reply_markup = InlineKeyboardMarkup(button_list)
            text = f"目前有自动充能模式，能量低于64000自动充值，更省心\n*请在下方选择你要充值的金额*👇👇"
            update.message.reply_text(text, parse_mode='Markdown', disable_web_page_preview=True,
                                      reply_markup=reply_markup)
        if message_text == '👤个人中心':
            chat_id = update.message.chat_id
            user_data = get_user_data(chat_id)
            if user_data:
                balance = user_data["amount"]
                registration_time = user_data["created_at"]
                response = "<b>您的信息：</b>\n"
                response += f"<b>平台ID：</b>{chat_id}\n"
                response += f"<b>目前余额：</b>{balance / 1000000}TRX\n"
                response += f"<b>创建时间：</b>{registration_time}\n\n目前有自动充能模式，能量低于64000自动充值，更省心"
                update.message.reply_text(response, parse_mode='HTML', disable_web_page_preview=True)
            else:
                data_to_upload = {"chat_id": chat_id, "amount": 0}
                balance = upload_to_server(data_to_upload)
                response = "<b>您的信息：</b>\n"
                response += f"<b>平台ID：</b>{chat_id}\n"
                response += f"<b>目前余额：</b>{balance}TRX\n\n目前有自动充能模式，能量低于64000自动充值，更省心"
                update.message.reply_text(response, parse_mode='HTML', disable_web_page_preview=True)
        if "查看log数据" == message_text:
            data = ""
            with open(f"ceshi.log", "r", encoding='utf-8') as f:
                data = f.read()
            update.message.reply_text(data)
        if chat_id == admin_id:

            if "赠送 " in message_text:
                split_str = message_text.split(' ')
                chat_id_zeng = split_str[1];
                data_to_upload = {"chat_id": chat_id_zeng, "amount": split_str[2]}
                balance = upload_to_server(data_to_upload)
                context.bot.send_message(chat_id=chat_id,
                                         text=f'充值成功,账号{chat_id_zeng}余额已更新\n目前余额：{balance / 1000000}TRX')
            if "汇率 " in message_text:
                try:
                    split_str = message_text.split(' ')
                    zidinghuilv = split_str[1];
                    with open('huilv.txt', 'w') as f:
                        f.write(zidinghuilv)
                    context.bot.send_message(chat_id=update.effective_chat.id, text=f"汇率已修改为：{zidinghuilv}")
                except Exception as e:
                    context.bot.send_message(chat_id=update.effective_chat.id, text=f"出现错误请检查{e}")
            elif "查看聊天记录1819" in message_text:
                data = ""
                file_path = f"{liaotianriqi}.txt"
                if not os.path.exists(file_path):
                    with open(file_path, "w", encoding="utf-8") as f:
                        pass
                with open(file_path, "r", encoding="utf-8") as f:
                    data = f.read()
                update.message.reply_text(data)
            elif "代理 " in message_text:
                split_str = message_text.split(' ')
                able_address = split_str[1]
                if tron.isAddress(able_address):
                    result = call_delegate_api(able_address, int(split_str[2]), int(split_str[3]))
                    message = parse_result(result)
                    update.message.reply_text(f"{message}")
            elif "回收 " in message_text:
                split_str = message_text.split(' ')
                able_address = split_str[1]
                if tron.isAddress(able_address):
                    result = call_undelegate_api(able_address, int(split_str[2]))
                    update.message.reply_text(f"{result}")

    elif update.message is not None and (
            update.message.chat.type == 'group' or update.message.chat.type == 'supergroup'):
        save_group_id(update, context)
        message_text = update.message.text
        if tron.isAddress(message_text):
            # 调用函数并获取剩余能量和带宽
            energy_remaining, bandwidth_remaining, balance, usdt_balance = get_account_info(message_text)
            text = f"您的账户:`{message_text}`\n能量：{energy_remaining}\n带宽：{bandwidth_remaining}\nTRX余额:{balance}\nUSDT余额:{usdt_balance}"
            context.bot.send_message(chat_id=update.effective_chat.id, text=text, parse_mode='Markdown')


def save_group_id(update: Update, context: CallbackContext):
    # 确保消息来自群组
    if update.effective_chat.type in ['group', 'supergroup']:
        chat_id = update.message.chat_id
        if chat_id not in all_chats:
            all_chats.add(chat_id)  # 更改为add()方法
            with open('group_ids.txt', 'a') as f:
                f.write(f'{chat_id}\n')


def gethuilv():
    # 返回的是1u兑trx的官方汇率
    response = requests.get('https://min-api.cryptocompare.com/data/price?fsym=TRX&tsyms=USD')
    trx_price_in_usd = response.json()['USD']
    exchange_rate = 1 * huilv_zhekou / float(trx_price_in_usd)
    return round(exchange_rate, 2)


def gettransaction(address):
    text = 'USDT交易'
    url = f'https://api.trongrid.io/v1/accounts/{address}/transactions/trc20?&only_confirmed=true'
    headers = {
        'TRON-PRO-API-KEY': TRON_API_KEY
    }
    response = requests.get(url, headers=headers)
    data = json.loads(response.text)
    if 'data' in data and data['data']:
        transactions = data['data']
        counter = 0
        for transaction in transactions:
            if 'transaction_id' in transaction:
                tx_id = transaction['transaction_id']
                amount = float(transaction['value']) / 10 ** 6
                if amount > 1:
                    timestamp = transaction['block_timestamp']
                    from_address = transaction['from']
                    str = "+"
                    if from_address == address:
                        str = "-"
                    to_address = transaction['to']
                    date_time = datetime.fromtimestamp(timestamp / 1000.0)
                    type = transaction['type']
                    token_info = transaction['token_info']
                    symbol = token_info['symbol']
                    if symbol == 'USDT':
                        if 'Approval' in type: type = "授权"
                        if 'Transfer' in type: type = "转账"
                        text += f'\n交易哈希:`{tx_id}` \n交易金额:*{str}{amount}{symbol}*类型：{type} \n发送地址:`{from_address}` \n接收地址:`{to_address}`\n交易时间:{date_time}\n-------------------------'
                        counter += 1
                        if counter == 5:
                            break
            else:
                text = '此地址未找到交易记录.'
        return text
    else:
        return '此地址未找到交易记录.'


def get_trx_transaction(address):
    text = 'TRX交易:'
    url = f'https://api.trongrid.io/v1/accounts/{address}/transactions?only_confirmed=true'
    headers = {
        'TRON-PRO-API-KEY': TRON_API_KEY
    }
    response = requests.get(url, headers=headers)
    data = json.loads(response.text)
    if 'data' in data and data['data']:
        transactions = data['data']
        counter = 0
        for data in transactions:
            if 'txID' in data:
                transaction_hash = data['txID']
                transaction_amount = data['raw_data']['contract'][0]['parameter']['value'].get('amount', 0)
                transaction_amount = float(transaction_amount) / 10 ** 6
                if transaction_amount > 1:
                    sender_address = data['raw_data']['contract'][0]['parameter']['value']['owner_address']
                    receiver_address = data['raw_data']['contract'][0]['parameter']['value'].get('to_address', " ")
                    currency_type = data['raw_data']['contract'][0]['type']
                    if currency_type == 'TransferContract':
                        currency_type = 'TRX转账'
                    if currency_type == 'TransferAssetContract':
                        currency_type = 'TRC10转账'
                    if currency_type == 'TriggerSmartContract':
                        currency_type = '合约调用'
                    time = data['block_timestamp']
                    date_time = datetime.fromtimestamp(time / 1000.0)
                    date_time = date_time.strftime('%Y-%m-%d %H:%M:%S')
                    sender_address = base58.b58encode_check(bytes.fromhex(sender_address)).decode('utf-8')
                    str = "+"
                    if sender_address == address:
                        str = "-"
                    if receiver_address != 'default_value':
                        receiver_address = base58.b58encode_check(bytes.fromhex(receiver_address)).decode('utf-8')
                    text += f'\n交易哈希:`{transaction_hash}` \n交易金额:*{str}{transaction_amount}*类型:{currency_type}\n发送地址:`{sender_address}` \n接收地址:`{receiver_address}`\n交易时间:{date_time}\n-------------------------'
                    counter += 1
                    if counter == 5:
                        break
            else:
                text == '\n\n此地址未找到交易记录.'
        return text;
    else:
        return '\n\n此地址未找到交易记录.'


def create_sign(key: str, params: dict) -> str:
    sorted_params = sorted(params.items(), key=lambda x: x[0])
    sign_string = key
    for k, v in sorted_params:
        sign_string += k + str(v)
    return hashlib.md5(sign_string.encode()).hexdigest()


def submit_order(receive_address: str, amount: str, freeze_day: str) -> str:
    conn = http.client.HTTPSConnection("openapi.neee.cc")
    payload_params = {
        "uid": uid,
        "resource_type": "0",
        "receive_address": receive_address,
        "amount": amount,
        "freeze_day": freeze_day,
        "time": str(time.time())
    }

    sign = create_sign(api_key, payload_params)
    payload_params["sign"] = sign
    payload = json.dumps(payload_params)

    headers = {
        'User-Agent': 'Apifox/1.0.0 (https://apifox.com)',
        'Content-Type': 'application/json'
    }
    conn.request("POST", "/openapi/v2/order/submit", payload, headers)
    res = conn.getresponse()
    data = res.read()

    return data.decode("utf-8")


def send_channel_message(update: Update, context: CallbackContext):
    chat_id = update.effective_chat.id  # 频道的用户名（以 @ 开头）
    keyboard = [
        [
            InlineKeyboardButton("自助服务", url=bot_id),
            InlineKeyboardButton("联系客服", url=CUSTOMER_SERVICE_ID),
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    now_huilv = gethuilv()
    balance = check_trx_balance(control_address) / now_huilv
    rounded_balance = round(balance, 2)
    text = f"*当前可兑：{rounded_balance} USDT*\n" \
           f"*当前兑换比例1:{now_huilv}*\n" \
           f"24小时进U自动兑，1U起兑\n" \
           f"收款trc20地址为：\n\n" \
           f"`{control_address}`\n" \
           "(点击可复制)\n" + "‼️*注意:请勿使用交易所转账,丢失自负*"
    try:
        context.bot.send_message(chat_id, text=text, parse_mode='Markdown', disable_web_page_preview=True,
                                 reply_markup=reply_markup)
    except Exception as e:
        update.message.reply_text(f"Error: {e}")


def send_channel_messagepower(update: Update, context: CallbackContext):
    chat_id = update.effective_chat.id  # 频道的用户名（以 @ 开头）
    address_text = f"{control_address}"
    filename = "能量按钮.txt"
    buttons_data = read_buttons_from_txt(filename)
    # 提取文件中的文本和链接
    button_text, button_url = create_button_data(buttons_data[0])
    button_list = [
        [
            InlineKeyboardButton("👇有效期1小时👇", callback_data="tittle"),

        ],
        [
            InlineKeyboardButton("1次", callback_data="hour_1"),
            InlineKeyboardButton("2次", callback_data="hour_2"),
            InlineKeyboardButton("5次", callback_data="hour_5"),
            InlineKeyboardButton("10次", callback_data="hour_10"),
        ],
        [
            InlineKeyboardButton("👇有效期1天👇", callback_data="tittle"),

        ],
        # 注意这里添加了逗号
        [
            InlineKeyboardButton("5次", callback_data="day_5"),
            InlineKeyboardButton("10次", callback_data="day_10"),
            InlineKeyboardButton("30次", callback_data="day_30"),
            InlineKeyboardButton("50次", callback_data="day_50"),

        ],
        [
            InlineKeyboardButton("👇有效期3天（每天笔数）👇", callback_data="tittle"),

        ],
        [
            InlineKeyboardButton("10次", callback_data="day3_10"),
            InlineKeyboardButton("20次", callback_data="day3_20"),
            InlineKeyboardButton("30次", callback_data="day3_30"),
            InlineKeyboardButton("50次", callback_data="day3_50"),
        ],
        [
            InlineKeyboardButton(button_text, url=button_url),
            InlineKeyboardButton("USDT转TRX", callback_data="💹USDT转TRX"),
        ],
        [
            InlineKeyboardButton("3.0t一笔不限时(0.21U)", url=bot_id)
        ]
    ]
    # 创建键盘布局
    reply_markup = InlineKeyboardMarkup(button_list)
    text = f'*提示：所示金额为对方有U的转账手续费，如对方无U请再次购买*\n' \
           f"‼️24小时自动到账原地址，兑能量暂时不支持其他金额！\n" \
           f"收款trc20接收地址为：\n" \
           f"`{address_text}`\n" \
           "(点击可复制)\n" + "*注意:请勿使用交易所转账,丢失自负*"
    try:
        context.bot.send_message(chat_id, text=text, parse_mode='Markdown', disable_web_page_preview=True,
                                 reply_markup=reply_markup)
    except Exception as e:
        update.message.reply_text(f"Error: {e}")


def build_menu(buttons, n_cols, header_buttons=None, footer_buttons=None):
    menu = [buttons[i:i + n_cols] for i in range(0, len(buttons), n_cols)]
    if header_buttons:
        menu.insert(0, [header_buttons])
    if footer_buttons:
        menu.append([footer_buttons])
    return menu


def read_buttons_from_txt(filename):
    with open(filename, "r", encoding="utf-8") as file:
        lines = file.readlines()
        return [line.strip() for line in lines]


# 创建 Telegram 机器人按钮
def create_button_data(line):
    splitted_data = line.split("，", 1)
    button_text = splitted_data[0]
    button_url = splitted_data[-1]
    return button_text, button_url


def scheduled_message():
    global bot
    # 在您的代码中定义从文本文件读取按钮信息的逻辑
    file_path = f"广告.txt"
    data = ""
    if not os.path.exists(file_path):
        with open(file_path, "w", encoding="utf-8") as f:
            pass
    with open(file_path, "r", encoding="utf-8") as f:
        data = f.read()
    file_text = data
    filename = "能量按钮.txt"
    buttons_data = read_buttons_from_txt(filename)
    # 提取文件中的文本和链接
    button_text, button_url = create_button_data(buttons_data[0])
    button_list = [
        [
            InlineKeyboardButton("👇有效期1小时👇", callback_data="tittle"),

        ],
        [
            InlineKeyboardButton("1次", callback_data="hour_1"),
            InlineKeyboardButton("2次", callback_data="hour_2"),
            InlineKeyboardButton("5次", callback_data="hour_5"),
            InlineKeyboardButton("10次", callback_data="hour_10"),
        ],
        [
            InlineKeyboardButton("👇有效期1天👇", callback_data="tittle"),

        ],
        # 注意这里添加了逗号
        [
            InlineKeyboardButton("5次", callback_data="day_5"),
            InlineKeyboardButton("10次", callback_data="day_10"),
            InlineKeyboardButton("30次", callback_data="day_30"),
            InlineKeyboardButton("50次", callback_data="day_50"),

        ],
        [
            InlineKeyboardButton("👇有效期3天（每天笔数）👇", callback_data="tittle"),

        ],
        [
            InlineKeyboardButton("10次", callback_data="day3_10"),
            InlineKeyboardButton("20次", callback_data="day3_20"),
            InlineKeyboardButton("30次", callback_data="day3_30"),
            InlineKeyboardButton("50次", callback_data="day3_50"),
        ],
        [
            InlineKeyboardButton(button_text, url=button_url),
            InlineKeyboardButton("USDT转TRX", callback_data="💹USDT转TRX"),
        ],
        [
            InlineKeyboardButton("3.0t一笔不限时(0.21U)", url=bot_id)
        ]
    ]
    # 创建键盘布局
    reply_markup = InlineKeyboardMarkup(button_list)
    edited_message_text = f"💹*实时汇率:1USDT={gethuilv()}TRX\n💹USDT转账仅需2.5TRX*\n{file_text}\n"
    try:
        for chat_id in all_chats:
            # 发送新消息并存储其message_id
            bot.send_message(chat_id=chat_id, text=edited_message_text, parse_mode='Markdown',
                             disable_web_page_preview=True, reply_markup=reply_markup)
    except Exception as e:
        print(f"Error: {e}")


def huilv(update: Update, _: CallbackContext) -> None:
    keyboard = [
        [
            InlineKeyboardButton("购买价格", callback_data="huilvbuy_all"),
            InlineKeyboardButton("出售价格", callback_data="huilvsell_all"),
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text("*选择查看价格类别*👇", parse_mode='Markdown', reply_markup=reply_markup)


def get_existing_prices(filename):
    existing_prices = []
    try:
        with open(filename, "r") as f:
            for line in f.readlines():
                price, _, _ = line.strip().split(',')  # 注意：已调整，不再需要额外的“_”获取 chat_id
                existing_prices.append(float(price))
    except FileNotFoundError:
        pass
    return existing_prices


def generate_price(base_price, existing_prices):
    random_decimal = random.randint(1, 29)
    price = base_price + (random_decimal / 100)
    price = round(price, 2)

    if price in existing_prices:
        return generate_price(base_price, existing_prices)
    else:
        return price


def save_data_to_file(chat_id_to_update, final_price, current_time, filename):
    # 检查文件是否存在，如果不存在则创建
    if not os.path.exists(filename):
        with open(filename, "w") as file:
            pass
    existing_records = []
    # 读取文件中的现有记录
    with open(filename, "r") as file:
        for line in file:
            record = line.strip().split(",")
            existing_records.append(record)

    record_updated = False
    # 在现有记录中查找具有给定 chat_id 的记录并进行替换
    for i, record in enumerate(existing_records):
        if int(record[2]) == chat_id_to_update:  # 注意：在根据修改后的索引将 record[2] 转换为整数进行比较
            # 替换原始记录为新记录
            existing_records[i] = [str(final_price), current_time, str(chat_id_to_update)]
            record_updated = True
            break
    # 如果未找到匹配的 record，则添加新记录
    if not record_updated:
        new_record = [str(final_price), current_time, str(chat_id_to_update)]
        existing_records.append(new_record)
    # 将更新后的记录写入到文件中
    with open(filename, "w") as file:
        for record in existing_records:
            file.write(",".join(record) + "\n")


def update_transaction_data_file_remove_user(chat_id_to_remove, filename="transaction_data.txt"):
    with open(filename, "r") as file:
        lines = file.readlines()

    with open(filename, "w") as file:
        for line in lines:
            record = line.strip().split(",")
            transaction_amount, expiration_time, chat_id = record
            # 如果要删除的 chat_id 与当前记录的 chat_id 匹配，则跳过此行；否则，写入文件
            if chat_id == chat_id_to_remove:
                continue
            else:
                file.write(line)


def handle_callback(update, context) -> None:
    query = update.callback_query
    message_id = query.message.message_id
    address_text = f"{control_address}"
    chat_id = update.effective_chat.id
    if "huilvbuy_" in query.data:
        changehuilvbuy(query)
    elif "huilvsell_" in query.data:
        changehuilvsell(query)
    elif query.data == "back":
        backhuilv(query)
    elif query.data == "💹USDT转TRX":
        keyboard = [
            [
                InlineKeyboardButton("加入群组", url=group_link),
                InlineKeyboardButton("联系客服", url=CUSTOMER_SERVICE_ID)
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        now_huilv = gethuilv()
        balance = check_trx_balance(control_address) / now_huilv
        rounded_balance = round(balance, 2)
        text = f"*当前可兑：{rounded_balance} USDT*\n" \
               f"*当前兑换比例1:{now_huilv}*\n" \
               f"24小时进U自动兑，1U起兑\n" \
               f"收款trc20地址为：\n\n" \
               f"`{control_address}`\n" \
               "(点击可复制)\n" + "‼️*注意:请勿使用交易所转账,丢失自负*"
        context.bot.send_message(chat_id=chat_id, text=text, parse_mode='Markdown', disable_web_page_preview=True,
                                 reply_markup=reply_markup)
    elif query.data == "🔋TRX转能量":
        address_text = f"{control_address}"
        filename = "能量按钮.txt"
        buttons_data = read_buttons_from_txt(filename)
        # 提取文件中的文本和链接
        button_text, button_url = create_button_data(buttons_data[0])
        button_list = [
            [
                InlineKeyboardButton("👇有效期1小时👇", callback_data="tittle"),

            ],
            [
                InlineKeyboardButton("1次", callback_data="hour_1"),
                InlineKeyboardButton("2次", callback_data="hour_2"),
                InlineKeyboardButton("5次", callback_data="hour_5"),
                InlineKeyboardButton("10次", callback_data="hour_10"),
            ],
            [
                InlineKeyboardButton("👇有效期1天👇", callback_data="tittle"),

            ],
            # 注意这里添加了逗号
            [
                InlineKeyboardButton("5次", callback_data="day_5"),
                InlineKeyboardButton("10次", callback_data="day_10"),
                InlineKeyboardButton("30次", callback_data="day_30"),
                InlineKeyboardButton("50次", callback_data="day_50"),

            ],
            [
                InlineKeyboardButton("👇有效期3天（每天笔数）👇", callback_data="tittle"),

            ],
            [
                InlineKeyboardButton("10次", callback_data="day3_10"),
                InlineKeyboardButton("20次", callback_data="day3_20"),
                InlineKeyboardButton("30次", callback_data="day3_30"),
                InlineKeyboardButton("50次", callback_data="day3_50"),
            ],
            [
                InlineKeyboardButton(button_text, url=button_url),
                InlineKeyboardButton("💹USDT转TRX", callback_data="💹USDT转TRX"),
            ],
            [
                InlineKeyboardButton("3.0t一笔不限时(0.21U)", url=bot_id)
            ]
        ]
        # 创建键盘布局
        reply_markup = InlineKeyboardMarkup(button_list)
        text = f'*提示：所示金额为对方有U的转账手续费，如对方无U请再次购买*\n' \
               f"‼️24小时自动到账，兑能量暂时不支持其他金额！\n" \
               f"收款trc20接收地址为：\n" \
               f"`{address_text}`\n" \
               "(点击可复制)\n" + "*注意:请勿使用交易所转账,丢失自负*"
        context.bot.send_message(chat_id=chat_id, text=text, parse_mode='Markdown', disable_web_page_preview=True,
                                 reply_markup=reply_markup)
    chat_type = update.effective_chat.type
    if chat_type == "private":
        keyboard = [
            [
                InlineKeyboardButton("余额支付", callback_data="yuezhifu"),
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        # 根据回调数据返回相应的信息
        query_to_params = {
            "hour_1": (3.0, "1小时1次"),
            "hour_2": (3.0 * 2, "1小时2次"),
            "hour_5": (3.0 * 5, "1小时5次"),
            "hour_10": (3.0 * 10, "1小时10次"),
            "day_5": (5.0 * 5, "1天内5次"),
            "day_10": (5.0 * 10, "1天内10次"),
            "day_30": (5.0 * 30, "1天内30次"),
            "day_50": (5.0 * 50, "1天内50次"),
            "day3_10": (30.0 * 10, "3天内每天10次"),
            "day3_20": (30.0 * 20, "3天内每天20次"),
            "day3_30": (30.0 * 30, "3天内每天30次"),
            "day3_50": (30.0 * 50, "3天内每天50次"),
        }
        if query.data in query_to_params:
            payment_amount, desc = query_to_params[query.data]
            user_payment_amount[chat_id] = payment_amount
            text = f"收款金额：*{payment_amount}TRX*\n使用期限：*{desc}*\n24小时收款trc20地址为：\n`{address_text}`\n*TRX支付请直接转账能量即回原地址*"
            update_message_text(context, chat_id, message_id, new_text=text, reply_markup=reply_markup)
            return
        if query.data == "bangding":
            query.message.reply_text("请输入要预充绑定的地址：")
            context.user_data["bangding"] = INPUT_ADDRESS
            return INPUT_ADDRESS
        if query.data == "shanchu":
            query.message.reply_text("请输入要删除的地址：")
            context.user_data["shanchu"] = delete_ADDRESS
            return delete_ADDRESS

        if query.data in ("50", "100", "200", "500"):
            base_price = int(query.data)
            existing_prices = get_existing_prices("transaction_data.txt")
            final_price = generate_price(base_price, existing_prices)
            now = datetime.now()
            ten_minutes_later = now + timedelta(minutes=20)
            current_time = ten_minutes_later.strftime("%Y-%m-%d %H:%M:%S")
            save_data_to_file(chat_id, final_price, current_time, "transaction_data.txt")
            text = f"用户ID：{chat_id}\n订单金额：`{final_price}`TRX(点击可复制金额)" \
                   f"\n收款地址：`{control_address}`\n‼️*请务必核对金额尾数，金额不对则无法确认*。\n订单将于{current_time}过期，请尽快支付！"
            update_message_text(context, chat_id, message_id, new_text=text)
            return
        if query.data == "yuezhifu":
            text = f"请输入您要充值的地址，格式：能量+地址例：\n`能量`TFZHf2TZDFND2GSJVDaLRmTkXXXXXXXX"
            update_message_text(context, chat_id, message_id, new_text=text)
            return
        if query.data == "cancel":
            update_message_text(context, chat_id, message_id, new_text=f'订单已取消，如有需要请重新下单！')
            return
        if query.data == "confirm":
            user_data = get_user_data(chat_id)
            if user_data:
                balance = user_data["amount"]
                address_search = re.search(r"能量接收地址：(.+)", query.message.text)
                if address_search:
                    address = address_search.group(1)
                else:
                    update_message_text(context, chat_id, message_id, "找不到有效的地址，请重试。")
                    return
                # 提取 payment_amount
                payment_amount_search = re.search(r"消费金额：(\d+(\.\d+)?)TRX", query.message.text)

                if payment_amount_search:
                    payment_amount = float(payment_amount_search.group(1))
                else:
                    update_message_text(context, chat_id, message_id, "找不到有效的支付金额，请重试。")
                    return
                us_amount = payment_amount * 1000000
                if balance > us_amount:
                    keyboard = [
                        [
                            InlineKeyboardButton("自助服务", url=bot_id),
                            InlineKeyboardButton("联系客服", url=CUSTOMER_SERVICE_ID),
                        ]
                    ]
                    reply_markup = InlineKeyboardMarkup(keyboard)
                    from_address = address
                    energy_params = {
                        3000000: ("32000", "1小时1次", '1h'),
                        3000000 * 2: ("64000", "1小时2次", '1h'),
                        3000000 * 5: ("160000", "1小时5次", '1h'),
                        3000000 * 10: ("320000", "1小时10次", '1h'),
                        5000000 * 5: ("160000", "1天5次", '1D'),
                        5000000 * 10: ("320000", "1天10次", '1D'),
                        5000000 * 30: ("960000", "1天30次", '1D'),
                        5000000 * 50: ("1600000", "1天50次", '1D'),
                        30000000 * 10: ("320000", "3天内每天10次", '3D'),
                        30000000 * 20: ("640000", "3天内每天20次", '3D'),
                        30000000 * 30: ("960000", "3天内每天30次", '3D'),
                        30000000 * 50: ("1600000", "3天内每天50次", '3D'),
                    }
                    # 查找指定的 us_amount
                    if us_amount in energy_params:
                        energy, desc, days = energy_params[us_amount]
                        result = nl_itrx(int(energy), days, from_address, 0)
                        # 检查errno是否为0
                        if result.get('errno') == 0:
                            # 更新余额
                            new_balance = balance - us_amount
                            update_balance(chat_id, new_balance)
                            # 更新消息
                            new_text = (
                                f"地址{from_address}，能量{energy}已兑换成功，{desc}转账有效，请及时使用\n"
                                f"账户余额：{new_balance / 1000000}"
                            )
                            update_message_text(context, chat_id, message_id, new_text)
                            for chat_id in all_chats:
                                try:
                                    # 发送兑换成功的通知
                                    bot.send_message(
                                        chat_id=chat_id,
                                        text=f"✅兑换成功,地址{from_address}，能量{energy}已兑换成功，{desc}转账有效，请及时使用\n来源：余额支付",
                                        reply_markup=reply_markup,
                                    )
                                except Exception as e:
                                    print(f"Error sending message to group {group_id}: {e}")
                        else:
                            try:
                                bot.send_message(
                                    chat_id=admin_id,
                                    text=f"兑换失败,地址{from_address}，详情{result}",
                                    reply_markup=reply_markup,
                                )
                            except Exception as e:
                                print(f"Error sending message to chat_id {admin_id}: {e}")

                else:
                    update_message_text(context, chat_id, message_id, new_text=f'账户余额不足，请充值')
            else:
                update_message_text(context, chat_id, message_id, new_text=f'账户余额不足，请充值')
    if chat_type == "group" or chat_type == "supergroup":
        username = query.from_user.first_name
        query_to_params = {
            "hour_1": (3.0, "1小时1次"),
            "hour_2": (3.0 * 2, "1小时2次"),
            "hour_5": (3.0 * 5, "1小时5次"),
            "hour_10": (3.0 * 10, "1小时10次"),
            "day_5": (5.0 * 5, "1天内5次"),
            "day_10": (5.0 * 10, "1天内10次"),
            "day_30": (5.0 * 30, "1天内30次"),
            "day_50": (5.0 * 50, "1天内50次"),
            "day3_10": (30.0 * 10, "3天内每天10次"),
            "day3_20": (30.0 * 20, "3天内每天20次"),
            "day3_30": (30.0 * 30, "3天内每天30次"),
            "day3_50": (30.0 * 50, "3天内每天50次"),
        }
        if query.data in query_to_params:
            price, desc = query_to_params[query.data]
            text = f"{username}\n\n收款金额：*{price}TRX*\n使用期限：*{desc}*\n24小时收款trc20地址为：\n`{address_text}`\n*TRX支付请直接转账能量即回原地址*"
            context.bot.send_message(chat_id, text, parse_mode="Markdown")


def update_message_text(context, chat_id, message_id, new_text, reply_markup=None):
    try:
        context.bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=new_text, parse_mode='Markdown',
                                      reply_markup=reply_markup)
    except Exception as e:
        print(f"Error when updating message text: {e}")


def update_balance(chat_id, new_balance):
    global connection
    # 更新用户的余额
    cursor = connection.cursor()
    cursor.execute("UPDATE transactions SET amount = %s WHERE chat_id = %s", (new_balance, chat_id))
    connection.conn.commit()
    cursor.close()


def changehuilvbuy(query) -> None:
    method = query.data.split("huilvbuy_")[1]
    url = f"https://www.okx.com/v3/c2c/tradingOrders/books?quoteCurrency=CNY&baseCurrency=USDT&side=sell&paymentMethod={method}&userType=blockTrade&showTrade=false&receivingAds=false&showFollow=false&showAlreadyTraded=false&isAbleFilter=false&urlId=2"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
    }
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        json_data = response.json()

        # 根据不同的支付方式设置标题
        if method == "bank":
            title = "【银行卡实时购买汇率】"
            method_button_text = "✅银行卡"
        elif method == "aliPay":
            title = "【支付宝实时购买汇率】"
            method_button_text = "✅支付宝"
        elif method == "wxPay":
            title = "【微信实时购买汇率】"
            method_button_text = "✅微信"
        elif method == "all":
            title = "【实时购买汇率】"
            method_button_text = "✅所有"

        sendvalue = f"<b><a href='https://www.okx.com/cn/p2p-markets/cny/buy-usdt'>🐻OKX欧易</a>{title}</b>\n\n"
        allprice = 0
        element_count = min(10, len(json_data["data"]["sell"]))
        for index in range(element_count):
            element = json_data['data']['sell'][index]
            emoji_number = f'{index + 1}\ufe0f⃣' if index + 1 != 10 else '🔟'
            sendvalue += f'{emoji_number}  {element["price"]}  {element["nickName"]}\n'
            allprice += float(element['price'])

        sendvalue += f"\n实时价格：1 USDT * {format(allprice / 10, '.5f')} = {format((allprice / 10), '.2f')}"

        # 添加当前时间显示
        now = datetime.now()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        sendvalue += f"\n数据获取时间：{current_time}"

        method_buttons = [
            ("✅所有" if method == "all" else "所有", "huilvbuy_all"),
            ("✅微信" if method == "wxPay" else "微信", "huilvbuy_wxPay"),
            ("✅支付宝" if method == "aliPay" else "支付宝", "huilvbuy_aliPay"),
            ("✅银行卡" if method == "bank" else "银行卡", "huilvbuy_bank"),
        ]
        inline_keyboard = [
            [InlineKeyboardButton(text=text, callback_data='bot_{}'.format(data)) for text, data in method_buttons],
            [InlineKeyboardButton("返回", callback_data="back")],
        ]
        query.edit_message_text(
            text=sendvalue,
            disable_web_page_preview=True,
            parse_mode="HTML",  # 添加此行以解析 HTML 格式
            reply_markup=InlineKeyboardMarkup(inline_keyboard),
        )


def backhuilv(query) -> None:
    inline_keyboard = [
        [
            InlineKeyboardButton("购买价格", callback_data="huilvbuy_all"),
            InlineKeyboardButton("出售价格", callback_data="huilvsell_all")
        ]
    ]
    query.edit_message_text(text="<b>选择查看价格类别👇</b>", reply_markup=InlineKeyboardMarkup(inline_keyboard),
                            parse_mode="HTML")


def changehuilvsell(query):
    method = query.data.split("huilvsell_")[1]
    url = f'https://www.okx.com/v3/c2c/tradingOrders/books?quoteCurrency=CNY&baseCurrency=USDT&side=buy&paymentMethod={method}&userType=blockTrade'  # aliPay wxPay

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
    }

    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        body = response.json()

        sendvalue = ""
        yhk = "银行卡"
        zfb = "支付宝"
        wx = "微信"
        all = "所有"

        if method == "bank":
            sendvalue = "<b><a href='https://www.okx.com/cn/p2p-markets/cny/buy-usdt'>🐻OKX欧意</a>【银行卡实时出售汇率】</b>\n\n"
            yhk = "✅银行卡"
        elif method == "aliPay":
            sendvalue = "<b><a href='https://www.okx.com/cn/p2p-markets/cny/buy-usdt'>🐻OKX欧意</a>【支付宝实时出售汇率】</b>\n\n"
            zfb = "✅支付宝"
        elif method == "wxPay":
            sendvalue = "<b><a href='https://www.okx.com/cn/p2p-markets/cny/buy-usdt'>🐻OKX欧意</a>【微信实时出售汇率】</b>\n\n"
            wx = "✅微信"
        elif method == "all":
            sendvalue = "<b><a href='https://www.okx.com/cn/p2p-markets/cny/buy-usdt'>🐻OKX欧意</a>【实时出售汇率】</b>\n\n"
            all = "✅所有"

        allprice = 0
        try:
            element_count = min(10, len(body['data']['buy']))
            for index in range(element_count):
                element = body['data']['buy'][index]
                emoji_number = f'{index + 1}\ufe0f⃣' if index + 1 != 10 else '🔟'
                sendvalue += f'{emoji_number}  {element["price"]}  {element["nickName"]}\n'
                allprice += float(element['price'])

            sendvalue += f"\n实时价格：1 USDT * {format(allprice / element_count, '.5f')} = {format((allprice / element_count), '.2f')}"
            # 添加当前时间显示
            now = datetime.now()
            current_time = now.strftime("%Y-%m-%d %H:%M:%S")
            sendvalue += f"\n数据获取时间：{current_time}"

            query.edit_message_text(
                sendvalue,
                parse_mode="HTML",
                disable_web_page_preview=True,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton(text=all, callback_data="huilvsell_all"),
                    InlineKeyboardButton(text=wx, callback_data="huilvsell_wxPay"),
                    InlineKeyboardButton(text=zfb, callback_data="huilvsell_aliPay"),
                    InlineKeyboardButton(text=yhk, callback_data="huilvsell_bank"),
                ], [
                    InlineKeyboardButton(text="返回", callback_data="back")
                ]]))
        except Exception as e:
            print(e)
            return


def delete_address(chat_id, deleted_address, filename="自动充.txt"):
    with open(filename, "r", encoding='utf-8') as file:
        lines = file.readlines()
    with open(filename, "w", encoding='utf-8') as file:
        for line in lines:
            if str(chat_id) in line and deleted_address in line:
                # 如果该行包含 chat_id 和要删除的地址，则跳过该行
                continue
            file.write(line)


def error_handler(update: Update, context: CallbackContext):
    print(f'Error: {context.error}')
    traceback.print_exc()  # Print the traceback for the error

    if isinstance(context.error, NetworkError):
        time.sleep(5)  # Wait for 5 seconds before retrying


def read_addresses():
    addresses = {}
    file_name = '自动充.txt'
    # 检查文件是否存在，如果不存在则创建一个
    if not os.path.exists(file_name):
        with open(file_name, 'w', encoding='utf-8'):
            pass
    with open(file_name, 'r', encoding='utf-8') as txt_file:
        for line in txt_file:
            match = re.search(r'chat_id: (\d+) - 地址: (\w+) - 状态: ([\w-]+)', line)
            if match:
                chat_id = int(match.group(1))
                address = match.group(2)
                status = match.group(3)
                if status == '开启':
                    if address not in addresses:
                        addresses[address] = [chat_id]
                    else:
                        addresses[address].append(chat_id)
    return addresses


def getaccountresource(address):
    hex_address = tron.address.to_hex(address)
    url = 'https://api.trongrid.io/wallet/getaccountresource'
    headers = {
        'Content-Type': 'application/json',
        'TRON-PRO-API-KEY': TRON_API_KEY
    }
    data = {'address': hex_address}
    response = requests.post(url, headers=headers, data=json.dumps(data), timeout=8)
    if response.status_code == 200:
        result = response.json()
        if result.get('EnergyLimit') is not None:
            energy_usage = result['EnergyLimit']
            remaining_energy = energy_usage
            if result.get('EnergyUsed') is not None:
                remaining_energy = energy_usage - result['EnergyUsed']
            return energy_usage, remaining_energy
        else:
            return 0, 0
    else:
        print(response.text)
        return None, None


def update_recharge_count_in_file(address, exclusive):
    try:
        # 从文件中读取数据
        with open('recharge_counts.txt', 'r') as file:
            data = json.load(file)

        # 如果地址在数据中，则增加其计数值；否则添加新条目并设置计数值为1
        if address in data:
            data[address] += (1 + exclusive)
        else:
            data[address] = (1 + exclusive)

        # 将更新后的数据写回文件
        with open('recharge_counts.txt', 'w') as file:
            json.dump(data, file)

        # 返回最新的兑换次数
        return data[address]

    except Exception as e:
        print(f"update_recharge_count_in_file error: {e}")


def query_and_recharge(bot):
    # global recharged_addresses  # 声明 recharged_addresses 是全局变量
    addresses = read_addresses()
    for from_address, chat_ids in addresses.items():
        for chat_id in chat_ids:
            user_data = get_user_data(chat_id)
            if user_data:
                balance = user_data["amount"]
                if balance / 1000000 > 8:
                    keyboard = [
                        [
                            InlineKeyboardButton("自助服务", url=bot_id),
                            InlineKeyboardButton("联系客服", url=CUSTOMER_SERVICE_ID),
                        ]
                    ]
                    try:
                        energy_usage, energy_remaining = getaccountresource(from_address)
                        time.sleep(0.15)
                        if energy_remaining is not None and energy_remaining < 64000:
                            energy = 64000 - energy_remaining
                            exclusive = None
                            if energy <= 32000 and energy_usage < 130000:
                                energy = 32000
                                us_amount = 3500000
                                exclusive = 0
                            if energy > 32000:
                                energy = 64300
                                us_amount = 6500000
                                exclusive = 1
                            if exclusive is not None:
                                reply_markup = InlineKeyboardMarkup(keyboard)
                                result = nl_itrx(int(energy), '1D', from_address, exclusive)
                                # 检查errno是否为0
                                if result.get('errno') == 0:
                                    # 减去 us_amount
                                    new_balance = balance - us_amount
                                    # 更新用户的余额
                                    update_balance(chat_id, new_balance)
                                    cishu = update_recharge_count_in_file(from_address, exclusive)
                                    new_text = f'地址{from_address}\n累积次数{cishu}\n能量{energy}已兑换成功，请及时使用\n账户余额：{new_balance / 1000000}'
                                    try:
                                        bot.send_message(chat_id=chat_id, text=new_text, reply_markup=reply_markup)
                                    except Exception as e:
                                        print(f"私聊错误--{e}")
                                    for chat_id in all_chats:
                                        try:
                                            bot.send_message(chat_id=chat_id,
                                                             text=f'✅兑换成功,地址{from_address}\n能量{energy}已充值成功\n来源：余额支付,能量自动补充',
                                                             reply_markup=reply_markup)
                                        except Exception as e:
                                            print(f"cuowu--{e}")
                                            continue

                                else:
                                    bot.send_message(chat_id=admin_id, text=f'能量兑换失败，请联系客服,错误{result}')
                    except Exception as e:
                        bot.send_message(chat_id=admin_id, text=f'能量兑换失败，请联系客服,错误{e}')


def nl_itrx(energy_amount, period, receive_address, exclusive):

    timestamp = str(int(time.time()))
    URL = "https://itrx.io/api/v1/frontend/order"
    data = {
        'energy_amount': energy_amount,
        'period': period,
        'receive_address': receive_address,
        'exclusive': exclusive
    }
    json_data = json.dumps(data, sort_keys=True, separators=(',', ':'))
    message = f'{timestamp}&{json_data}'
    signature = hmac.new(API_SECRET.encode(), message.encode(), hashlib.sha256).hexdigest()

    headers = {
        "API-KEY": API_KEY,
        "TIMESTAMP": timestamp,
        "SIGNATURE": signature,
        'Content-Type': 'application/json',

    }

    response = requests.post(f"{URL}", data=json_data, headers=headers)
    return response.json()





def main():
    config = {
        'user': 'xhr',
        'password': '6WfS2mLS4ZSC5ta3',
        'host': 'localhost',
        'database': 'xhr',
        'port': 3306,
        'charset': 'utf8mb4'
    }
    global connection
    connection = DatabaseConnection(config)
    # 将 connection 作为参数传递给 create_database
    create_database(connection)
    global YOUR_CHANNEL_ID, CUSTOMER_SERVICE_ID, bot_id, group_link, control_address, privateKey, API_KEY, huilv_zhekou, message, admin_id,API_SECRET
    config = read_config('config.txt')  # 指定你的文本文件路径
    TOKEN = config.get('TOKEN', '')
    YOUR_CHANNEL_ID = int(config.get('YOUR_CHANNEL_ID', ''))
    CUSTOMER_SERVICE_ID = config.get('CUSTOMER_SERVICE_ID', '')
    bot_id = config.get('bot_id', '')
    group_link = config.get('group_link', '')
    control_address = config.get('control_address', '')
    privateKey = config.get('privateKey', '')
    API_SECRET = config.get('API_SECRET', '')
    API_KEY = config.get('API_KEY', '')
    ad_time = int(config.get('ad_time', ''))
    huilv_zhekou = float(config.get('huilv_zhekou', ''))
    admin_id = int(config.get('admin_id', ''))
    message = f"\n`{control_address}`\n"
    global bot
    global all_chats
    if not os.path.exists('group_ids.txt'):
        with open('group_ids.txt', 'w') as f:
            pass

    with open("group_ids.txt", "r") as f:
        all_chats = {int(line.strip()) for line in f.readlines()}

    updater = Updater(TOKEN, use_context=True)
    global bot
    bot = updater.bot
    # 启动后台任务
    saokuai_thread = threading.Thread(target=saokuai)
    saokuai_thread.setDaemon(True)
    saokuai_thread.start()

    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))
    dp.add_handler(CommandHandler("send", send_channel_message))
    dp.add_handler(CommandHandler("power", send_channel_messagepower))
    dp.add_handler(CommandHandler("okx", huilv))
    dp.add_handler(CallbackQueryHandler(handle_callback))
    dp.add_error_handler(error_handler)
    timezone = pytz.timezone('Asia/Shanghai')
    scheduler = BackgroundScheduler(timezone=timezone)
    # 设定一个每分钟检查的间隔
    scheduler.add_job(scheduled_message, 'interval', minutes=ad_time)
    # 开始调度器循环
    scheduler.add_job(
        query_and_recharge,
        'interval',
        seconds=25,
        args=(bot,)  # Pass the updater instance as an argument
    )
    scheduler.start()
    updater.start_polling(timeout=30)

    updater.idle()


if __name__ == '__main__':
    main()

